<?php
/**
 * Link as button
 */
function sx_button( $atts, $content = null ) {
	$a = shortcode_atts( array(
        'colors' => 'A',
		'border' => 'normal', //normal, hard, lite, no
		'link' => '#',
		'new_window' => 'no', //yes, no
		'hover' => 'light', //light, dark
    ), $atts );
	if($a['border'] === 'yes'){
		$a['border'] = 'normal';
	}
	$cl = 'button';
	$col = strtolower($a['colors']);
	$cl .= ' ' . 'heading-' . $col;
	$cl .= ' ' . 'background-' . $col;
	if($a['border']!=='no'){
		$cl .= ' ' . 'border-' . $a['border'] . '-' . $col;
	}
	$cl .= ' hover-' . $a['hover'];
	return '<a class="' . $cl . '" href="' . $a['link'] . '"'. ($a['new_window'] == 'yes' ? ' target="_blank"' : '') .'>' . do_shortcode( $content ) . '</a>';
}
add_shortcode( 'sx_button', 'sx_button');
/**
 * Icon link
 */
function sx_icon_link( $atts, $content = null ) {
	$a = shortcode_atts( array(
        'link' => '#',
        'new_window' => 'no',
        'class' => 'fa fa-link',
    ), $atts );
	return '<a href="' . $a['link'] . '"'. ($a['new_window'] == 'yes' ? ' target="_blank"' : '') .'><i class="' . $a['class'] . '"></i></a>';
}
add_shortcode( 'sx_icon_link', 'sx_icon_link');
/**
 * Icon
 */
function sx_icon( $atts, $content = null ) {
	$a = shortcode_atts( array(
        'class' => 'fa fa-link',
    ), $atts );
	return '<i class="' . $a['class'] . '"></i>';
}
add_shortcode( 'sx_icon', 'sx_icon');
/**
 * Animated text
 */
function sx_animated_text( $atts, $content = '' ) {
	if($content != ''){
		$a = shortcode_atts( array(
			'effect' => 'A' //A, B
		), $atts );
		$opt = '';
		if($a['effect'] == 'A'){
			$opt = "{loop:true, in:{effect:'flipInY', reverse:true}, out:{effect:'flipOutY', reverse:true}}";
		}else{
			$opt= "{loop:true, in:{effect:'fadeInRight', reverse:true}, out:{effect:'fadeOutLeft', sequence:true}}";;
		}
		$res = '<span class="textillate" data-textillate-options="' . $opt . '"><span class="texts">';
		$arr = explode ('/', $content);
		foreach ($arr as $value){
			$res .= '<span>' . trim($value) . '</span>';
		}
		$res .= '</span></span>';
		return $res;
	}else{
		return '';
	}
}
add_shortcode( 'sx_animated_text', 'sx_animated_text');
/**
 * Banner cell.
 */
function sx_banner( $atts, $content = null ) {
	$a = shortcode_atts( array(
        'colors' => 'A',
		'title' => '',
		'subtitle' => '',
		'overlay' => 'success'
    ), $atts );
	$col = strtolower($a['colors']);
	$over = strtolower($a['overlay']);
	$res = '<div class="banner-box background-' . $col . ' heading-' . $col . '">';
	$res .= '<div class="banner-cell"><div class="banner-title">' . $a['title'] . '</div><div class="banner-subtitle">' . $a['subtitle'] . '</div></div>';
	$res .= '<div class="banner-cell ' . $over . '-background">' . do_shortcode( $content ) . '</div>';
	$res .= '</div>';
	return $res;
}
add_shortcode( 'sx_banner', 'sx_banner');
/**
 * Counter. Like Our Numbers.
 */
function sx_counter( $atts, $content = null ) {
	$a = shortcode_atts( array(
        'count' => '0',
        'label' => esc_html__('Count', 'skrollex-extension'),
        'colors' => 'A',
    ), $atts );
	$colors = strtolower($a['colors']);
	return '<div class="counter background-' . $colors . ' heading-' . $colors . '"><div class="count player background-10-light">' . $a['count'] . '</div><div class="caption heading-' . $colors . '">' . $a['label'] . '</div></div>';
}
add_shortcode( 'sx_counter', 'sx_counter');
/**
 * Skill bar. Like Our Skills.
 */
function sx_skill( $atts, $content = null ) {
	$a = shortcode_atts( array(
        'percent' => '50',
        'label' => 'Skill',
        'bar-colors' => 'A',
        'label-colors' => 'A',
    ), $atts );
	$bar_color = strtolower($a['bar-colors']);
	$label_color = strtolower($a['label-colors']);
	return	'<div class="skillbar clearfix background-' . $bar_color . ' player" data-percent="' . $a['percent'] . '%">' .
				'<div class="skillbar-title background-' . $label_color . ' heading-' . $label_color . '"><span class="skillbar-label">' . $a['label'] . '</span></div>' .
				'<div class="skillbar-bar background-' . $label_color . '"></div>' .
				'<div class="skill-bar-percent heading-' . $bar_color . '">' . $a['percent'] . '%</div>' .
			'</div>';
}
add_shortcode( 'sx_skill', 'sx_skill');
/**
 * List of recent posts.
 */
function sx_recent_posts($atts) {
	$a = shortcode_atts( array(
        'number_posts' => '5',
		'more_text' => esc_html__( 'More...', 'skrollex-extension' )
    ), $atts );
	$res = '<ul>';
	$recent_posts = wp_get_recent_posts(array(
		'numberposts' => $a['number_posts']
	));
	foreach( $recent_posts as $recent ){
		$stit = wp_strip_all_tags(strip_shortcodes($recent["post_title"]));
		$res .= '<li><a href="' . get_permalink($recent["ID"]) . '">' .   apply_filters('skrollex_non_rich', $stit) . '</a></li>';
	}
	if($a['more_text']!== ''){
		if( get_option( 'show_on_front' ) == 'page' ){
			$res .= '<li><a href="' . get_permalink( get_option('page_for_posts' ) ) . '">' . $a['more_text'] . '</a></li>';
		}else{
			$res .= '<li><a href="' . home_url()  . '">' . $a['more_text'] . '</a></li>';
		}
	}
	$res .= '</ul>';
	return $res;
}
add_shortcode( 'sx_recent_posts', 'sx_recent_posts');
/**
 * Google map
 */
function sx_map( $atts, $content = null ) {
	$a = shortcode_atts( array(
        'button' => esc_html__('Locate Us On Map', 'skrollex-extension'),
        'latitude' => '42.487606',
        'longitude' => '-71.115661',
        'zoom' => '14',
		'colors' => 'A',
		'border' => 'normal', //normal, hard, lite, no
    ), $atts );
	if($a['border'] === 'yes'){
		$a['border'] = 'normal';
	}
	$col = strtolower($a['colors']);
	$bord = '';
	if($a['border']!=='no'){
		$bord .= ' border-' . $a['border'] . '-' . $col;
	}
	$res  = '<span class="google-map-button">';
	$res .= '<a class="map-open button background-' . $col . $bord . ' heading-' . $col . '" data-map-overlay=".map-overlay" href="#">' . $a['button'] . '</a>';
	$res .= '<span class="map-canvas" data-latitude="' . $a['latitude'] . '" data-longitude="' . $a['longitude'] . '" data-zoom="' . $a['zoom'] . '">';
	$res .= do_shortcode( $content );		
	$res .= '</span>';
	$res .= '</span>';
	return $res;
}
add_shortcode( 'sx_map', 'sx_map');
/**
 * Marker for Google Msap
 */
function sx_map_marker( $atts, $content = null ) {
	$a = shortcode_atts( array(
        'text' => esc_html__('Our awesome location', 'skrollex-extension' ),
        'latitude' => '42.487606',
        'longitude' => '-71.115661',
    ), $atts );
	return  '<span class="map-marker" data-latitude="' . $a['latitude'] . '" data-longitude="' . $a['longitude'] . '" data-text="' . $a['text'] . '"></span>';
}
add_shortcode( 'sx_map_marker', 'sx_map_marker');
/**
 * Load HTML content with shortcodes from file.
 */
function sx_content( $atts ) {
	$a = shortcode_atts( array(
        'file' => 'readme.txt',
    ), $atts );
	return  do_shortcode(file_get_contents(get_stylesheet_directory() . '/' . $a['file']));
}
add_shortcode( 'sx_content', 'sx_content');