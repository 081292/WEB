<?php
/**
* Plugin Name: Skrollex Extension
* Version: 1.1
* Plugin URI: http://www.x40.ru
* Description: Skrollex Extension for Layers WP
* Author: x40
* Author URI: http://www.x40.ru/
*
* Text Domain: skrollex-extension
* Domain Path: /languages/
*/
define('SKROLLEX_EXTENSION_DIR', plugin_dir_path( __FILE__ ));
define('SKROLLEX_EXTENSION_URI', plugin_dir_url( __FILE__ ));
$this_theme = wp_get_theme();
$parent_theme = $this_theme->parent();
$this_theme_name = $this_theme->get('Name');
$parent_theme_name = $parent_theme ? $parent_theme->get('Name') : $this_theme_name;
define('SKROLLEX_EXTENSION_IS_LAYERS', $this_theme_name === 'Skrollex' || $parent_theme_name === "Layers");
require_once( 'includes/shortcodes.php' );
if ( ! defined( 'ABSPATH' ) ) exit;
require_once( 'includes/assets-ver.php' );
if (!function_exists('skrollex_extension_init')) {
	function skrollex_extension_init() {
		// Localization
		load_plugin_textdomain('skrollex-extension', FALSE, dirname(plugin_basename(__FILE__)) . "/languages");
	}
}
add_action('plugins_loaded', 'skrollex_extension_init');
